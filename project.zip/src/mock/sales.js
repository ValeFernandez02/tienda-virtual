const sales = [
  {
    id: 1,
    userId: 1,
    products: [
      { productId: 1, quantity: 2 },
      { productId: 3, quantity: 1 }
    ],
    date: "2023-05-15T10:30:00Z",
    total: 359980,
    status: "completada"
  }
];

export default sales;