export const getProducts = () => {
  const products = JSON.parse(localStorage.getItem('sportProducts'));
  return products || [];
};

export const saveProducts = (products) => {
  localStorage.setItem('sportProducts', JSON.stringify(products));
};

export const getUsers = () => {
  const users = JSON.parse(localStorage.getItem('sportUsers'));
  return users || [];
};

export const saveUsers = (users) => {
  localStorage.setItem('sportUsers', JSON.stringify(users));
};

export const getSales = () => {
  const sales = JSON.parse(localStorage.getItem('sportSales'));
  return sales || [];
};

export const saveSale = (sale) => {
  const sales = getSales();
  sales.push(sale);
  localStorage.setItem('sportSales', JSON.stringify(sales));
  return sales;
};

export const registerUser = (emailOrPhone, password, name) => {
  const users = getUsers();
  const newUser = {
    id: Date.now(),
    email: emailOrPhone.includes('@') ? emailOrPhone : '',
    phone: emailOrPhone.includes('@') ? '' : emailOrPhone,
    password,
    name
  };
  users.push(newUser);
  saveUsers(users);
  return newUser;
};

export const loginUser = (emailOrPhone, password) => {
  const users = getUsers();
  return users.find(user => 
    (user.email === emailOrPhone || user.phone === emailOrPhone) && 
    user.password === password
  );
};