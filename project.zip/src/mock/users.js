const users = [
  {
    id: 1,
    email: "usuario@ejemplo.com",
    phone: "+1234567890",
    password: "password123",
    name: "Usuario Ejemplo"
  }
];

export default users;