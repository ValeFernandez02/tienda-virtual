import React, { useState } from 'react';
import SportAuthForm from './SportAuthForm';
import { registerUser, loginUser, resetPassword } from '../utils/auth';

const SportAuthGate = ({ onAuthSuccess }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleRegister = (emailOrPhone, password, name) => {
    const user = registerUser(emailOrPhone, password, name);
    if (user) {
      setIsAuthenticated(true);
      onAuthSuccess(user);
    }
  };

  const handleLogin = (emailOrPhone, password) => {
    const user = loginUser(emailOrPhone, password);
    if (user) {
      setIsAuthenticated(true);
      onAuthSuccess(user);
    } else {
      alert("Credenciales incorrectas");
    }
  };

  const handleResetPassword = (emailOrPhone) => {
    const success = resetPassword(emailOrPhone);
    if (success) {
      alert("Se ha enviado un link de recuperación a tu correo o teléfono");
    }
  };

  if (isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <SportAuthForm 
        onRegister={handleRegister}
        onLogin={handleLogin}
        onResetPassword={handleResetPassword}
      />
    </div>
  );
};

export default SportAuthGate;